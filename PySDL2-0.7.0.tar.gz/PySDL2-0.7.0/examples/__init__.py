"""Examples for PySDL2.

This package contains the examples for sdl2.
"""

