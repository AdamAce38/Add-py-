#if defined(NUMPY)
#include "numpy/oldnumeric.h"
#else
#include "Numeric/arrayobject.h"
#endif
