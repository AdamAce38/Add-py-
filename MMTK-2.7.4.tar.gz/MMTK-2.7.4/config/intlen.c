#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv)
{
  printf("%d\n", (int)sizeof(long));
}
