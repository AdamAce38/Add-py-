#include <stdio.h>
#include <math.h>

int main(int argc, char **argv)
{
  printf("%f\n", sqrt(2.));
}
