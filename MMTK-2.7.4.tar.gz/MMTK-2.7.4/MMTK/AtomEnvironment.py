# This module defines the environment in which atom definition files
# are executed.

from MMTK.Units import *
