.. index:: Pyrolite, Java, .NET, C#

*******************************************
Pyrolite - client library for Java and .NET
*******************************************

This library allows your Java or .NET program to interface very easily with
the Python world. It uses the Pyro protocol to call methods on remote
objects.

https://github.com/irmen/Pyrolite


The 5.x version works with Pyro5.
(Use the 4.x version for Pyro4).
