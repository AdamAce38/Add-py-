:mod:`Pyro5.utils.echoserver` --- Built-in echo server for testing purposes
===========================================================================

.. automodule:: Pyro5.utils.echoserver
   :members:
