:mod:`Pyro5.socketutil` --- Socket related utilities
====================================================

.. automodule:: Pyro5.socketutil
   :members:
