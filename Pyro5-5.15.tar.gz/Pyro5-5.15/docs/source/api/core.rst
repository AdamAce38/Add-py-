:mod:`Pyro5.core` --- core Pyro logic
=====================================

.. automodule:: Pyro5.core
    :members:
