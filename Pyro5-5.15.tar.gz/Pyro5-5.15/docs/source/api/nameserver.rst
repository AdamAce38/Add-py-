:mod:`Pyro5.nameserver` --- Pyro name server
============================================

.. automodule:: Pyro5.nameserver
   :members:

.. autoclass:: Pyro5.nameserver.NameServer
   :members:

