:mod:`Pyro5.client` --- Client code logic
=========================================

.. automodule:: Pyro5.client
    :members:
