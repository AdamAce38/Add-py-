:mod:`Pyro5.compatibility.Pyro4` --- Pyro4 backward compatibility layer
=======================================================================

.. automodule:: Pyro5.compatibility.Pyro4
    :members:
