import sys
from setuptools import setup

setup()
