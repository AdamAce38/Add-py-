This example shows the metadata capabilities of the name server
and the use of the PYROMETA magic uri protocol.

Before running the example.py, make sure the name server is running.
You should choose an appropriate storage type for the name server
(dbm storage doesn't support metadata).
