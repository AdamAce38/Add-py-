""" Utility functions and classes for SRP

Context : SRP
Module  : Net.py
Version : 1.0.0
Author  : Stefano Covino
Date    : 16/07/2010
E-mail  : stefano.covino@brera.inaf.it
URL:    : http://www.merate.mi.astro.it/utenti/covino

Usage   : to be imported

Remarks :

History : (16/07/2010) First version.

"""


# WEB constants

WebQueryOK      =       200


