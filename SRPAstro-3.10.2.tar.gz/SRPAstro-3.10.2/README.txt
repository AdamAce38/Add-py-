

Installation


tar xvzf SRPAstro-�version�.tar.gz
cd SRPAstro-�version�.tar
python setup.py build


then as superuser:

python setup.py install 



Stefano Covino
INAF / Brera Astronomical Observatory
Via E. Bianchi 46, 23807
Merate (LC)
http://www.merate.mi.astro.it/covino
stefano.covino@brera.inaf.it


